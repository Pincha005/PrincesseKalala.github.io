

// Attendre que le document soit complètement chargé
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. Sélectionner les éléments dont on a besoin
    const burgerButton = document.querySelector('.burger'); // Le bouton burger
    const navbarMenu = document.querySelector('.navbar');   // Le menu à afficher/cacher
    
    // 2. Ajouter un événement "click" sur le bouton burger
    burgerButton.addEventListener('click', function() {
        
        // 3. Vérifier si le menu est déjà visible
        if (navbarMenu.style.display === 'block') {
            // Si oui, le cacher
            navbarMenu.style.display = 'none';
        } else {
            // Si non, l'afficher
            navbarMenu.style.display = 'flex';
        }
    });
    
    // 4. Optionnel: fermer le menu quand on clique sur un lien (pour mobile)
    const navLinks = document.querySelectorAll('.navbar ul li a');
    navLinks.forEach(function(link) {
        link.addEventListener('click', function() {
            // Vérifier si on est sur mobile (comme dans votre CSS)
            if (window.innerWidth <= 768) {
                navbarMenu.style.display = 'none';
            }
        });
    });
    
    // 5. Optionnel: gérer le redimensionnement de la fenêtre
    window.addEventListener('resize', function() {
        // Si l'écran est plus grand que 768px (comme dans votre CSS)
        if (window.innerWidth > 768) {
            navbarMenu.style.display = 'block';
        } else {
            navbarMenu.style.display = 'none';
        }
    });
});